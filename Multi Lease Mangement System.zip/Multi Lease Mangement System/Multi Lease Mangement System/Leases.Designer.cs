﻿namespace Multi_Lease_Mangement_System
{
    partial class Leases
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Datetheleasecontractbeginslabel = new System.Windows.Forms.Label();
            this.Datetheleasecontractbeginsbox = new System.Windows.Forms.TextBox();
            this.Firstpaymentdatelabel = new System.Windows.Forms.Label();
            this.FirstpaymentdateBox = new System.Windows.Forms.TextBox();
            this.Amountofmonthlypaymentlabel = new System.Windows.Forms.Label();
            this.AmountofmonthlypaymentBox = new System.Windows.Forms.TextBox();
            this.Numberofmonthlypaymentslabel = new System.Windows.Forms.Label();
            this.NumberofmonthlypaymentsBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.WhichvehicletheleaseisforBox1 = new System.Windows.Forms.TextBox();
            this.Whichcustomertheleaseisfor = new System.Windows.Forms.Label();
            this.WhichcustomertheleaseisforBox = new System.Windows.Forms.TextBox();
            this.Thetermsofthelease = new System.Windows.Forms.Label();
            this.ThetermsoftheleaseBox = new System.Windows.Forms.TextBox();
            this.Insert4 = new System.Windows.Forms.Button();
            this.Update4 = new System.Windows.Forms.Button();
            this.Delete4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Datetheleasecontractbeginslabel
            // 
            this.Datetheleasecontractbeginslabel.AutoSize = true;
            this.Datetheleasecontractbeginslabel.Location = new System.Drawing.Point(51, 45);
            this.Datetheleasecontractbeginslabel.Name = "Datetheleasecontractbeginslabel";
            this.Datetheleasecontractbeginslabel.Size = new System.Drawing.Size(234, 20);
            this.Datetheleasecontractbeginslabel.TabIndex = 0;
            this.Datetheleasecontractbeginslabel.Text = "Date the lease contract begins :";
            // 
            // Datetheleasecontractbeginsbox
            // 
            this.Datetheleasecontractbeginsbox.Location = new System.Drawing.Point(302, 45);
            this.Datetheleasecontractbeginsbox.Name = "Datetheleasecontractbeginsbox";
            this.Datetheleasecontractbeginsbox.Size = new System.Drawing.Size(156, 26);
            this.Datetheleasecontractbeginsbox.TabIndex = 1;
            // 
            // Firstpaymentdatelabel
            // 
            this.Firstpaymentdatelabel.AutoSize = true;
            this.Firstpaymentdatelabel.Location = new System.Drawing.Point(140, 97);
            this.Firstpaymentdatelabel.Name = "Firstpaymentdatelabel";
            this.Firstpaymentdatelabel.Size = new System.Drawing.Size(145, 20);
            this.Firstpaymentdatelabel.TabIndex = 2;
            this.Firstpaymentdatelabel.Text = "First payment date:";
            // 
            // FirstpaymentdateBox
            // 
            this.FirstpaymentdateBox.Location = new System.Drawing.Point(302, 97);
            this.FirstpaymentdateBox.Name = "FirstpaymentdateBox";
            this.FirstpaymentdateBox.Size = new System.Drawing.Size(156, 26);
            this.FirstpaymentdateBox.TabIndex = 3;
            // 
            // Amountofmonthlypaymentlabel
            // 
            this.Amountofmonthlypaymentlabel.AutoSize = true;
            this.Amountofmonthlypaymentlabel.Location = new System.Drawing.Point(74, 149);
            this.Amountofmonthlypaymentlabel.Name = "Amountofmonthlypaymentlabel";
            this.Amountofmonthlypaymentlabel.Size = new System.Drawing.Size(211, 20);
            this.Amountofmonthlypaymentlabel.TabIndex = 4;
            this.Amountofmonthlypaymentlabel.Text = "Amount of monthly payment:";
            // 
            // AmountofmonthlypaymentBox
            // 
            this.AmountofmonthlypaymentBox.Location = new System.Drawing.Point(302, 149);
            this.AmountofmonthlypaymentBox.Name = "AmountofmonthlypaymentBox";
            this.AmountofmonthlypaymentBox.Size = new System.Drawing.Size(156, 26);
            this.AmountofmonthlypaymentBox.TabIndex = 5;
            // 
            // Numberofmonthlypaymentslabel
            // 
            this.Numberofmonthlypaymentslabel.AutoSize = true;
            this.Numberofmonthlypaymentslabel.Location = new System.Drawing.Point(66, 203);
            this.Numberofmonthlypaymentslabel.Name = "Numberofmonthlypaymentslabel";
            this.Numberofmonthlypaymentslabel.Size = new System.Drawing.Size(219, 20);
            this.Numberofmonthlypaymentslabel.TabIndex = 6;
            this.Numberofmonthlypaymentslabel.Text = "Number of monthly payments:";
            // 
            // NumberofmonthlypaymentsBox
            // 
            this.NumberofmonthlypaymentsBox.Location = new System.Drawing.Point(302, 203);
            this.NumberofmonthlypaymentsBox.Name = "NumberofmonthlypaymentsBox";
            this.NumberofmonthlypaymentsBox.Size = new System.Drawing.Size(156, 26);
            this.NumberofmonthlypaymentsBox.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Which vehicle the lease is for:";
            // 
            // WhichvehicletheleaseisforBox1
            // 
            this.WhichvehicletheleaseisforBox1.Location = new System.Drawing.Point(302, 258);
            this.WhichvehicletheleaseisforBox1.Name = "WhichvehicletheleaseisforBox1";
            this.WhichvehicletheleaseisforBox1.Size = new System.Drawing.Size(156, 26);
            this.WhichvehicletheleaseisforBox1.TabIndex = 9;
            // 
            // Whichcustomertheleaseisfor
            // 
            this.Whichcustomertheleaseisfor.AutoSize = true;
            this.Whichcustomertheleaseisfor.Location = new System.Drawing.Point(51, 306);
            this.Whichcustomertheleaseisfor.Name = "Whichcustomertheleaseisfor";
            this.Whichcustomertheleaseisfor.Size = new System.Drawing.Size(234, 20);
            this.Whichcustomertheleaseisfor.TabIndex = 10;
            this.Whichcustomertheleaseisfor.Text = "Which customer the lease is for:";
            // 
            // WhichcustomertheleaseisforBox
            // 
            this.WhichcustomertheleaseisforBox.Location = new System.Drawing.Point(302, 306);
            this.WhichcustomertheleaseisforBox.Name = "WhichcustomertheleaseisforBox";
            this.WhichcustomertheleaseisforBox.Size = new System.Drawing.Size(156, 26);
            this.WhichcustomertheleaseisforBox.TabIndex = 11;
            // 
            // Thetermsofthelease
            // 
            this.Thetermsofthelease.AutoSize = true;
            this.Thetermsofthelease.Location = new System.Drawing.Point(114, 360);
            this.Thetermsofthelease.Name = "Thetermsofthelease";
            this.Thetermsofthelease.Size = new System.Drawing.Size(171, 20);
            this.Thetermsofthelease.TabIndex = 12;
            this.Thetermsofthelease.Text = "The terms of the lease:";
            // 
            // ThetermsoftheleaseBox
            // 
            this.ThetermsoftheleaseBox.Location = new System.Drawing.Point(302, 360);
            this.ThetermsoftheleaseBox.Name = "ThetermsoftheleaseBox";
            this.ThetermsoftheleaseBox.Size = new System.Drawing.Size(156, 26);
            this.ThetermsoftheleaseBox.TabIndex = 13;
            // 
            // Insert4
            // 
            this.Insert4.Location = new System.Drawing.Point(106, 418);
            this.Insert4.Name = "Insert4";
            this.Insert4.Size = new System.Drawing.Size(75, 32);
            this.Insert4.TabIndex = 14;
            this.Insert4.Text = "Insert";
            this.Insert4.UseVisualStyleBackColor = true;
            this.Insert4.Click += new System.EventHandler(this.Insert4_Click);
            // 
            // Update4
            // 
            this.Update4.Location = new System.Drawing.Point(237, 418);
            this.Update4.Name = "Update4";
            this.Update4.Size = new System.Drawing.Size(75, 32);
            this.Update4.TabIndex = 15;
            this.Update4.Text = "Update";
            this.Update4.UseVisualStyleBackColor = true;
            this.Update4.Click += new System.EventHandler(this.Update4_Click);
            // 
            // Delete4
            // 
            this.Delete4.Location = new System.Drawing.Point(382, 418);
            this.Delete4.Name = "Delete4";
            this.Delete4.Size = new System.Drawing.Size(75, 32);
            this.Delete4.TabIndex = 16;
            this.Delete4.Text = "Delete";
            this.Delete4.UseVisualStyleBackColor = true;
            this.Delete4.Click += new System.EventHandler(this.Delete4_Click);
            // 
            // Leases
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 482);
            this.Controls.Add(this.Delete4);
            this.Controls.Add(this.Update4);
            this.Controls.Add(this.Insert4);
            this.Controls.Add(this.ThetermsoftheleaseBox);
            this.Controls.Add(this.Thetermsofthelease);
            this.Controls.Add(this.WhichcustomertheleaseisforBox);
            this.Controls.Add(this.Whichcustomertheleaseisfor);
            this.Controls.Add(this.WhichvehicletheleaseisforBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NumberofmonthlypaymentsBox);
            this.Controls.Add(this.Numberofmonthlypaymentslabel);
            this.Controls.Add(this.AmountofmonthlypaymentBox);
            this.Controls.Add(this.Amountofmonthlypaymentlabel);
            this.Controls.Add(this.FirstpaymentdateBox);
            this.Controls.Add(this.Firstpaymentdatelabel);
            this.Controls.Add(this.Datetheleasecontractbeginsbox);
            this.Controls.Add(this.Datetheleasecontractbeginslabel);
            this.Name = "Leases";
            this.Text = "Leases";
            this.Load += new System.EventHandler(this.Leases_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Datetheleasecontractbeginslabel;
        private System.Windows.Forms.TextBox Datetheleasecontractbeginsbox;
        private System.Windows.Forms.Label Firstpaymentdatelabel;
        private System.Windows.Forms.TextBox FirstpaymentdateBox;
        private System.Windows.Forms.Label Amountofmonthlypaymentlabel;
        private System.Windows.Forms.TextBox AmountofmonthlypaymentBox;
        private System.Windows.Forms.Label Numberofmonthlypaymentslabel;
        private System.Windows.Forms.TextBox NumberofmonthlypaymentsBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox WhichvehicletheleaseisforBox1;
        private System.Windows.Forms.Label Whichcustomertheleaseisfor;
        private System.Windows.Forms.TextBox WhichcustomertheleaseisforBox;
        private System.Windows.Forms.Label Thetermsofthelease;
        private System.Windows.Forms.TextBox ThetermsoftheleaseBox;
        private System.Windows.Forms.Button Insert4;
        private System.Windows.Forms.Button Update4;
        private System.Windows.Forms.Button Delete4;
    }
}