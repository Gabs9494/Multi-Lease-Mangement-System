﻿namespace Multi_Lease_Mangement_System
{
    partial class Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FullNameBox1 = new System.Windows.Forms.TextBox();
            this.FullNamelabel = new System.Windows.Forms.Label();
            this.Addresslabel = new System.Windows.Forms.Label();
            this.AddressBox1 = new System.Windows.Forms.TextBox();
            this.Citylabel = new System.Windows.Forms.Label();
            this.CityBox1 = new System.Windows.Forms.TextBox();
            this.Provincelabel = new System.Windows.Forms.Label();
            this.ProvinceBox1 = new System.Windows.Forms.TextBox();
            this.PostalCodelabel = new System.Windows.Forms.Label();
            this.PostalCodeBox1 = new System.Windows.Forms.TextBox();
            this.PhoneNumberlabel = new System.Windows.Forms.Label();
            this.PhoneNumberBox = new System.Windows.Forms.TextBox();
            this.Insert5 = new System.Windows.Forms.Button();
            this.update5 = new System.Windows.Forms.Button();
            this.Delete5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.customerIDTextbox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // FullNameBox1
            // 
            this.FullNameBox1.Location = new System.Drawing.Point(160, 55);
            this.FullNameBox1.Name = "FullNameBox1";
            this.FullNameBox1.Size = new System.Drawing.Size(116, 26);
            this.FullNameBox1.TabIndex = 1;
            // 
            // FullNamelabel
            // 
            this.FullNamelabel.AutoSize = true;
            this.FullNamelabel.Location = new System.Drawing.Point(26, 55);
            this.FullNamelabel.Name = "FullNamelabel";
            this.FullNamelabel.Size = new System.Drawing.Size(84, 20);
            this.FullNamelabel.TabIndex = 2;
            this.FullNamelabel.Text = "Full Name:";
            // 
            // Addresslabel
            // 
            this.Addresslabel.AutoSize = true;
            this.Addresslabel.Location = new System.Drawing.Point(51, 105);
            this.Addresslabel.Name = "Addresslabel";
            this.Addresslabel.Size = new System.Drawing.Size(72, 20);
            this.Addresslabel.TabIndex = 3;
            this.Addresslabel.Text = "Address:";
            this.Addresslabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // AddressBox1
            // 
            this.AddressBox1.Location = new System.Drawing.Point(160, 102);
            this.AddressBox1.Name = "AddressBox1";
            this.AddressBox1.Size = new System.Drawing.Size(116, 26);
            this.AddressBox1.TabIndex = 4;
            // 
            // Citylabel
            // 
            this.Citylabel.AutoSize = true;
            this.Citylabel.Location = new System.Drawing.Point(69, 152);
            this.Citylabel.Name = "Citylabel";
            this.Citylabel.Size = new System.Drawing.Size(39, 20);
            this.Citylabel.TabIndex = 5;
            this.Citylabel.Text = "City:";
            // 
            // CityBox1
            // 
            this.CityBox1.Location = new System.Drawing.Point(160, 152);
            this.CityBox1.Name = "CityBox1";
            this.CityBox1.Size = new System.Drawing.Size(116, 26);
            this.CityBox1.TabIndex = 6;
            // 
            // Provincelabel
            // 
            this.Provincelabel.AutoSize = true;
            this.Provincelabel.Location = new System.Drawing.Point(36, 209);
            this.Provincelabel.Name = "Provincelabel";
            this.Provincelabel.Size = new System.Drawing.Size(73, 20);
            this.Provincelabel.TabIndex = 7;
            this.Provincelabel.Text = "Province:";
            // 
            // ProvinceBox1
            // 
            this.ProvinceBox1.Location = new System.Drawing.Point(160, 209);
            this.ProvinceBox1.Name = "ProvinceBox1";
            this.ProvinceBox1.Size = new System.Drawing.Size(116, 26);
            this.ProvinceBox1.TabIndex = 8;
            // 
            // PostalCodelabel
            // 
            this.PostalCodelabel.AutoSize = true;
            this.PostalCodelabel.Location = new System.Drawing.Point(24, 269);
            this.PostalCodelabel.Name = "PostalCodelabel";
            this.PostalCodelabel.Size = new System.Drawing.Size(99, 20);
            this.PostalCodelabel.TabIndex = 9;
            this.PostalCodelabel.Text = "Postal Code:";
            // 
            // PostalCodeBox1
            // 
            this.PostalCodeBox1.Location = new System.Drawing.Point(160, 269);
            this.PostalCodeBox1.Name = "PostalCodeBox1";
            this.PostalCodeBox1.Size = new System.Drawing.Size(116, 26);
            this.PostalCodeBox1.TabIndex = 10;
            // 
            // PhoneNumberlabel
            // 
            this.PhoneNumberlabel.AutoSize = true;
            this.PhoneNumberlabel.Location = new System.Drawing.Point(9, 337);
            this.PhoneNumberlabel.Name = "PhoneNumberlabel";
            this.PhoneNumberlabel.Size = new System.Drawing.Size(119, 20);
            this.PhoneNumberlabel.TabIndex = 11;
            this.PhoneNumberlabel.Text = "Phone Number:";
            // 
            // PhoneNumberBox
            // 
            this.PhoneNumberBox.Location = new System.Drawing.Point(160, 337);
            this.PhoneNumberBox.Name = "PhoneNumberBox";
            this.PhoneNumberBox.Size = new System.Drawing.Size(116, 26);
            this.PhoneNumberBox.TabIndex = 12;
            // 
            // Insert5
            // 
            this.Insert5.Location = new System.Drawing.Point(40, 481);
            this.Insert5.Name = "Insert5";
            this.Insert5.Size = new System.Drawing.Size(75, 35);
            this.Insert5.TabIndex = 13;
            this.Insert5.Text = "Insert";
            this.Insert5.UseVisualStyleBackColor = true;
            this.Insert5.Click += new System.EventHandler(this.Insert5_Click);
            // 
            // update5
            // 
            this.update5.Location = new System.Drawing.Point(160, 481);
            this.update5.Name = "update5";
            this.update5.Size = new System.Drawing.Size(75, 35);
            this.update5.TabIndex = 14;
            this.update5.Text = "Update";
            this.update5.UseVisualStyleBackColor = true;
            this.update5.Click += new System.EventHandler(this.update5_Click);
            // 
            // Delete5
            // 
            this.Delete5.Location = new System.Drawing.Point(276, 481);
            this.Delete5.Name = "Delete5";
            this.Delete5.Size = new System.Drawing.Size(75, 35);
            this.Delete5.TabIndex = 15;
            this.Delete5.Text = "Delete";
            this.Delete5.UseVisualStyleBackColor = true;
            this.Delete5.Click += new System.EventHandler(this.Delete5_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 401);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 20);
            this.label1.TabIndex = 16;
            this.label1.Text = "CustomerID:";
            // 
            // customerIDTextbox1
            // 
            this.customerIDTextbox1.Location = new System.Drawing.Point(160, 394);
            this.customerIDTextbox1.Name = "customerIDTextbox1";
            this.customerIDTextbox1.Size = new System.Drawing.Size(116, 26);
            this.customerIDTextbox1.TabIndex = 17;
            // 
            // Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(468, 528);
            this.Controls.Add(this.customerIDTextbox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Delete5);
            this.Controls.Add(this.update5);
            this.Controls.Add(this.Insert5);
            this.Controls.Add(this.PhoneNumberBox);
            this.Controls.Add(this.PhoneNumberlabel);
            this.Controls.Add(this.PostalCodeBox1);
            this.Controls.Add(this.PostalCodelabel);
            this.Controls.Add(this.ProvinceBox1);
            this.Controls.Add(this.Provincelabel);
            this.Controls.Add(this.CityBox1);
            this.Controls.Add(this.Citylabel);
            this.Controls.Add(this.AddressBox1);
            this.Controls.Add(this.Addresslabel);
            this.Controls.Add(this.FullNamelabel);
            this.Controls.Add(this.FullNameBox1);
            this.Name = "Customers";
            this.Text = "Customer Information";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox FullNameBox1;
        private System.Windows.Forms.Label FullNamelabel;
        private System.Windows.Forms.Label Addresslabel;
        private System.Windows.Forms.TextBox AddressBox1;
        private System.Windows.Forms.Label Citylabel;
        private System.Windows.Forms.TextBox CityBox1;
        private System.Windows.Forms.Label Provincelabel;
        private System.Windows.Forms.TextBox ProvinceBox1;
        private System.Windows.Forms.Label PostalCodelabel;
        private System.Windows.Forms.TextBox PostalCodeBox1;
        private System.Windows.Forms.Label PhoneNumberlabel;
        private System.Windows.Forms.TextBox PhoneNumberBox;
        private System.Windows.Forms.Button Insert5;
        private System.Windows.Forms.Button update5;
        private System.Windows.Forms.Button Delete5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox customerIDTextbox1;
    }
}

